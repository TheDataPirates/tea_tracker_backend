const Sequelize = require("sequelize");

const sequelize = require("../database/db");

module.exports = sequelize.define("Lot_Container");
